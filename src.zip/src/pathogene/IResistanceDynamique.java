package pathogene;
public interface IResistanceDynamique {
    float calculerNouvelleResistance(float oldRes, float dm);    
} 
