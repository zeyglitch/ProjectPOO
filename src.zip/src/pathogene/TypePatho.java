package pathogene;
public enum TypePatho {
    VIRUS,
    BACTERIE,
}
